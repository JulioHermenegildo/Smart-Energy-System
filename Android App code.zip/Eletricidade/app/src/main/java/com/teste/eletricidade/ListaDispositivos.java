package com.teste.eletricidade;

import android.app.ListActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class ListaDispositivos extends ListActivity {

    private BluetoothAdapter meuBluetoothAdapter2 = null;

    static  String ENDERECO_MAC = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ArrayAdapter<String> ArrayBluetooth = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        //Obtem adaptador ?

        meuBluetoothAdapter2 = BluetoothAdapter.getDefaultAdapter();

        //obtem a lista de bluetooths emparelhados
        Set<BluetoothDevice> dispositivosEmparelhados = meuBluetoothAdapter2.getBondedDevices();
        if(dispositivosEmparelhados.size() > 0){
            for(BluetoothDevice dispositivo : dispositivosEmparelhados){
                String nomeBt = dispositivo.getName(); //nome do bt
                String MACBt = dispositivo.getAddress();//endereço MAC do bluetooth
                ArrayBluetooth.add(nomeBt + "\n" + MACBt); //ordena a lista por nome + endereço
            }
        }
        setListAdapter(ArrayBluetooth);

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        String informaçãoGeral = ((TextView) v).getText().toString();
        Toast.makeText(getApplicationContext(), "Info:" + informaçãoGeral, Toast.LENGTH_LONG).show();

        String enderecoMAC = informaçãoGeral.substring(informaçãoGeral.length()-17);
        //Toast.makeText(getApplicationContext(), "Mac:" + endereçoMAC, Toast.LENGTH_LONG).show();

        //enviar estes dados para a activity principal

        Intent RetornaMAC = new Intent();
        RetornaMAC.putExtra(ENDERECO_MAC, enderecoMAC); //"copia" o valor de endereçoMAC para ENDEREÇO_W pois esta é golbal

        setResult(RESULT_OK, RetornaMAC); //resultado da escolha do bluetooth foi concliuda com sucesso
        finish(); //Fecha a lista de bluetooths
    }
}
