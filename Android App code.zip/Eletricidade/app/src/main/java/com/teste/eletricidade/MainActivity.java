package com.teste.eletricidade;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity {


    Button btnConexao, Defenicoes, Consumos;

    private static final int SOLICITA_ATIVACAO = 1;
    private static final int SOLICITA_CONEXAO = 2;

    BluetoothAdapter meuBluetoothAdapter = null;
    BluetoothSocket meuSocket = null;

    public static String MAC;
    boolean conexao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //visualiza a pagina principal

        btnConexao = (Button) findViewById(R.id.Btnconexao);  //Declara botoes
        Defenicoes = (Button) findViewById(R.id.Defenicoes);
        Consumos = (Button) findViewById(R.id.Consumos);

        meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();//verifica se tem bluetooth



        if (meuBluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "Seu dispositivo não possui bluetooth", Toast.LENGTH_LONG).show();
        } else if (!meuBluetoothAdapter.isEnabled()) {
            Intent ativaBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(ativaBluetooth, SOLICITA_ATIVACAO);
        }



        btnConexao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (conexao) {
                    //desconectar
                    try {
                        meuSocket.close();
                        Toast.makeText(getApplicationContext(), "Bluetooth foi desligado", Toast.LENGTH_LONG).show();
                        conexao = false;


                    } catch (IOException erro) {
                        Toast.makeText(getApplicationContext(), "Ocorreu um erro" + erro, Toast.LENGTH_LONG).show();
                    }
                } else {
                    Intent abreLista = new Intent(MainActivity.this, ListaDispositivos.class);
                    startActivityForResult(abreLista, SOLICITA_CONEXAO);
                }
            }
        });

        Defenicoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                intent.putExtra("MAC", MAC);
                intent.putExtra("conexao", conexao);
                startActivity(intent);
                //connectedThread.enviar(data_completa+"aa");
                //connectedThread.enviar(hora_atual+"aaaaaaah");




            }
        });

        Consumos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), "Consumos", Toast.LENGTH_LONG).show();
                Intent intent2 = new Intent(MainActivity.this, Main3Activity.class);
                intent2.putExtra("MAC", MAC);
                intent2.putExtra("conexao", conexao);
                startActivity(intent2);
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case SOLICITA_ATIVACAO:
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(getApplicationContext(), "Bluetooth foi ativado", Toast.LENGTH_LONG).show(); //aparece uma msg
                } else {
                    Toast.makeText(getApplicationContext(), "Bluetooth não foi ativado, a aplicação será terminada", Toast.LENGTH_LONG).show();
                    finish(); //termina a app
                }
                break;

            case SOLICITA_CONEXAO:
                if (resultCode == Activity.RESULT_OK) {

                    MAC = data.getExtras().getString(ListaDispositivos.ENDERECO_MAC);
                    //meuDevice = meuBluetoothAdapter.getRemoteDevice(MAC);
                    //try {
                    //    meuSocket = meuDevice.createRfcommSocketToServiceRecord(MEU_UUID); //CRIAÇAO DE CANAL DE COMUNICACÃO
                    //    meuSocket.connect(); //conecta ao bluetooth
                    conexao = true;
                    //    connectedThread = new MainActivity.ConnectedThread(meuSocket);
                    //    connectedThread.start();


                    Toast.makeText(getApplicationContext(), "Conectado com" + MAC, Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Falha ao obter o MAC", Toast.LENGTH_LONG).show();
                }

        }

    }


}