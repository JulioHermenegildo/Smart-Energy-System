package com.teste.eletricidade;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

public class Main3Activity extends Activity {

    private static final int MESSAGE_READ = 3;

    ConnectedThread connectedThread;

    Handler mHandler;
    StringBuilder dadosBluetooth = new StringBuilder();

    BluetoothAdapter meuBluetoothAdapter3 = null;
    BluetoothDevice meuDevice3 = null;
    BluetoothSocket meuSocket3 = null;
    Button retroceder;

    public static String MAC;
    public String tarifa;
    public String potencia;
    boolean conexao;
    UUID MEU_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //CANAL DE COMUNICAÇÃO ENTRE DISPOSITIVOS


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        meuBluetoothAdapter3 = BluetoothAdapter.getDefaultAdapter();//verifica se tem bluetooth

        //Obter data e hora
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat dateFormat_hora = new SimpleDateFormat("HH:mm");
        Date data = new Date();

        Calendar cal = Calendar.getInstance();
        cal.setTime(data);
        Date data_atual = cal.getTime();

        final String data_completa = dateFormat.format(data_atual);
        final String hora_atual = dateFormat_hora.format(data_atual);
        
        Intent intent = getIntent();
        MAC= intent.getStringExtra("MAC");
        conexao= intent.getBooleanExtra("conexao", true);
        tarifa = intent.getStringExtra("tarifa");
        potencia = intent.getStringExtra("potencia");


        if (conexao==true){
            meuDevice3 = meuBluetoothAdapter3.getRemoteDevice(MAC );
            Toast.makeText(getApplicationContext(), "Conexao: "+ conexao, Toast.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "MAC: "+ MAC, Toast.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "potencia: "+ potencia, Toast.LENGTH_LONG).show();


            try {
                meuSocket3 = meuDevice3.createRfcommSocketToServiceRecord(MEU_UUID); //CRIAÇAO DE CANAL DE COMUNICACÃO
                meuSocket3.connect();
                connectedThread = new Main3Activity.ConnectedThread(meuSocket3);
                connectedThread.start();
                connectedThread.enviar(data_completa+"aa");
                connectedThread.enviar(hora_atual+"aaaaaaah");
                connectedThread.enviar(tarifa);
                connectedThread.enviar(potencia);


                Toast.makeText(getApplicationContext(),"Conectado com" + MAC, Toast.LENGTH_LONG).show();

            } catch (IOException erro) {
                conexao=false;
                Toast.makeText(getApplicationContext(),"Ocorreu um erro"+ erro, Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(getApplicationContext(), "Nao foi conectado" + MAC, Toast.LENGTH_LONG).show();
        }




        mHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == MESSAGE_READ){

                    String recebidos = (String) msg.obj; //recolhe os dados
                    dadosBluetooth.append(recebidos);    //junta os dados recolhidos a dadosBluetooth

                    int fimInfo = dadosBluetooth.indexOf("}"); //compara se o ultimo char é o }, se for fimInfo>0 chegou ao fim
                    if (fimInfo > 0){

                        String dadosCompletos = dadosBluetooth.substring(0,fimInfo);
                        int tamanhoInfo = dadosCompletos.length();

                        if (dadosBluetooth.charAt(0)== '{'){ //se chegou aqui entao possui inicio e fim "{}"

                            String dadosFinais = dadosBluetooth.substring(1, tamanhoInfo);
                            Log.d("Recebidos:", dadosFinais);
                        }
                        dadosBluetooth.delete(0, dadosBluetooth.length());

                    }


                }

            }
        };

        //Apresentação de dados

        final TextView Janeiro = (TextView) findViewById(R.id.Janeiro);
        final TextView JaneiroConsumo = (TextView) findViewById(R.id.JaneiroConsumo);
        final TextView JaneiroPreco = (TextView) findViewById(R.id.JaneiroPreco);
        final TextView Fevereiro = (TextView) findViewById(R.id.Fevereiro);
        final TextView FevereiroConsumo = (TextView) findViewById(R.id.FevereiroConsumo);
        final TextView FevereiroPreco = (TextView) findViewById(R.id.FevereiroPreco);
        final TextView Marco = (TextView) findViewById(R.id.Marco);
        final TextView MarcoConsumo = (TextView) findViewById(R.id.MarcoConsumo);
        final TextView MarcoPreco = (TextView) findViewById(R.id.MarcoPreco);
        final TextView Abril = (TextView) findViewById(R.id.Abril);
        final TextView AbrilConsumo = (TextView) findViewById(R.id.AbrilConsumo);
        final TextView AbrilPreco = (TextView) findViewById(R.id.AbrilPreco);
        final TextView Maio = (TextView) findViewById(R.id.Maio);
        final TextView MaioConsumo = (TextView) findViewById(R.id.MaioConsumo);
        final TextView MaioPreco = (TextView) findViewById(R.id.MaioPreco);
        final TextView Junho = (TextView) findViewById(R.id.Junho);
        final TextView JunhoConsumo = (TextView) findViewById(R.id.JunhoConsumo);
        final TextView JunhoPreco = (TextView) findViewById(R.id.JunhoPreco);
        final TextView Julho = (TextView) findViewById(R.id.Julho);
        final TextView JulhoConsumo = (TextView) findViewById(R.id.JulhoConsumo);
        final TextView JulhoPreco = (TextView) findViewById(R.id.JulhoPreco);
        final TextView Agosto = (TextView) findViewById(R.id.Agosto);
        final TextView AgostoConsumo = (TextView) findViewById(R.id.AgostoConsumo);
        final TextView AgostoPreco = (TextView) findViewById(R.id.AgostoPreco);
        final TextView Setembro = (TextView) findViewById(R.id.Setembro);
        final TextView SetembroConsumo = (TextView) findViewById(R.id.SetembroConsumo);
        final TextView SetembroPreco = (TextView) findViewById(R.id.SetembroPreco);
        final TextView Outubro = (TextView) findViewById(R.id.Outubro);
        final TextView OutubroConsumo = (TextView) findViewById(R.id.OutubroConsumo);
        final TextView OutubroPreco = (TextView) findViewById(R.id.OutubroPreco);
        final TextView Novembro = (TextView) findViewById(R.id.Novembro);
        final TextView NovembroConsumo = (TextView) findViewById(R.id.NovembroConsumo);
        final TextView NovembroPreco = (TextView) findViewById(R.id.NovembroPreco);
        final TextView Dezembro = (TextView) findViewById(R.id.Dezembro);
        final TextView DezembroConsumo = (TextView) findViewById(R.id.DezembroConsumo);
        final TextView DezembroPreco = (TextView) findViewById(R.id.DezembroPreco);
        final LinearLayout detalhes = (LinearLayout) findViewById(R.id.detalhes);
        final Button retroceder = (Button) findViewById(R.id.retroceder);

        Janeiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fevereiro.setVisibility(View.GONE);
                FevereiroConsumo.setVisibility(View.GONE);
                FevereiroPreco.setVisibility(View.GONE);
                Marco.setVisibility(View.GONE);
                MarcoConsumo.setVisibility(View.GONE);
                MarcoPreco.setVisibility(View.GONE);
                Abril.setVisibility(View.GONE);
                AbrilConsumo.setVisibility(View.GONE);
                AbrilPreco.setVisibility(View.GONE);
                Maio.setVisibility(View.GONE);
                MaioConsumo.setVisibility(View.GONE);
                MaioPreco.setVisibility(View.GONE);
                Junho.setVisibility(View.GONE);
                JunhoConsumo.setVisibility(View.GONE);
                JunhoPreco.setVisibility(View.GONE);
                Julho.setVisibility(View.GONE);
                JulhoConsumo.setVisibility(View.GONE);
                JulhoPreco.setVisibility(View.GONE);
                Agosto.setVisibility(View.GONE);
                AgostoConsumo.setVisibility(View.GONE);
                AgostoPreco.setVisibility(View.GONE);
                Setembro.setVisibility(View.GONE);
                SetembroConsumo.setVisibility(View.GONE);
                SetembroPreco.setVisibility(View.GONE);
                Outubro.setVisibility(View.GONE);
                OutubroConsumo.setVisibility(View.GONE);
                OutubroPreco.setVisibility(View.GONE);
                Novembro.setVisibility(View.GONE);
                NovembroConsumo.setVisibility(View.GONE);
                NovembroPreco.setVisibility(View.GONE);
                Dezembro.setVisibility(View.GONE);
                DezembroConsumo.setVisibility(View.GONE);
                DezembroPreco.setVisibility(View.GONE);
                detalhes.setVisibility(View.VISIBLE);
                retroceder.setVisibility(View.VISIBLE);
            }
        });
        Fevereiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Janeiro.setVisibility(View.GONE);
                JaneiroConsumo.setVisibility(View.GONE);
                JaneiroPreco.setVisibility(View.GONE);
                Marco.setVisibility(View.GONE);
                MarcoConsumo.setVisibility(View.GONE);
                MarcoPreco.setVisibility(View.GONE);
                Abril.setVisibility(View.GONE);
                AbrilConsumo.setVisibility(View.GONE);
                AbrilPreco.setVisibility(View.GONE);
                Maio.setVisibility(View.GONE);
                MaioConsumo.setVisibility(View.GONE);
                MaioPreco.setVisibility(View.GONE);
                Junho.setVisibility(View.GONE);
                JunhoConsumo.setVisibility(View.GONE);
                JunhoPreco.setVisibility(View.GONE);
                Julho.setVisibility(View.GONE);
                JulhoConsumo.setVisibility(View.GONE);
                JulhoPreco.setVisibility(View.GONE);
                Agosto.setVisibility(View.GONE);
                AgostoConsumo.setVisibility(View.GONE);
                AgostoPreco.setVisibility(View.GONE);
                Setembro.setVisibility(View.GONE);
                SetembroConsumo.setVisibility(View.GONE);
                SetembroPreco.setVisibility(View.GONE);
                Outubro.setVisibility(View.GONE);
                OutubroConsumo.setVisibility(View.GONE);
                OutubroPreco.setVisibility(View.GONE);
                Novembro.setVisibility(View.GONE);
                NovembroConsumo.setVisibility(View.GONE);
                NovembroPreco.setVisibility(View.GONE);
                Dezembro.setVisibility(View.GONE);
                DezembroConsumo.setVisibility(View.GONE);
                DezembroPreco.setVisibility(View.GONE);
                detalhes.setVisibility(View.VISIBLE);
                retroceder.setVisibility(View.VISIBLE);
            }
        });


        retroceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Janeiro.setVisibility(View.VISIBLE);
                JaneiroConsumo.setVisibility(View.VISIBLE);
                JaneiroPreco.setVisibility(View.VISIBLE);
                Fevereiro.setVisibility(View.VISIBLE);
                FevereiroConsumo.setVisibility(View.VISIBLE);
                FevereiroPreco.setVisibility(View.VISIBLE);
                Marco.setVisibility(View.VISIBLE);
                MarcoConsumo.setVisibility(View.VISIBLE);
                MarcoPreco.setVisibility(View.VISIBLE);
                Abril.setVisibility(View.VISIBLE);
                AbrilConsumo.setVisibility(View.VISIBLE);
                AbrilPreco.setVisibility(View.VISIBLE);
                Maio.setVisibility(View.VISIBLE);
                MaioConsumo.setVisibility(View.VISIBLE);
                MaioPreco.setVisibility(View.VISIBLE);
                Junho.setVisibility(View.VISIBLE);
                JunhoConsumo.setVisibility(View.VISIBLE);
                JunhoPreco.setVisibility(View.VISIBLE);
                Julho.setVisibility(View.VISIBLE);
                JulhoConsumo.setVisibility(View.VISIBLE);
                JulhoPreco.setVisibility(View.VISIBLE);
                Agosto.setVisibility(View.VISIBLE);
                AgostoConsumo.setVisibility(View.VISIBLE);
                AgostoPreco.setVisibility(View.VISIBLE);
                Setembro.setVisibility(View.VISIBLE);
                SetembroConsumo.setVisibility(View.VISIBLE);
                SetembroPreco.setVisibility(View.VISIBLE);
                Outubro.setVisibility(View.VISIBLE);
                OutubroConsumo.setVisibility(View.VISIBLE);
                OutubroPreco.setVisibility(View.VISIBLE);
                Novembro.setVisibility(View.VISIBLE);
                NovembroConsumo.setVisibility(View.VISIBLE);
                NovembroPreco.setVisibility(View.VISIBLE);
                Dezembro.setVisibility(View.VISIBLE);
                DezembroConsumo.setVisibility(View.VISIBLE);
                DezembroPreco.setVisibility(View.VISIBLE);
                detalhes.setVisibility(View.GONE);
                retroceder.setVisibility(View.GONE);
            }
        });
    }


    public class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];  // buffer store for the stream
            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);
                    String DadosBt = new String(buffer, 0, bytes); //Transforma bytes em string
                    // Send the obtained bytes to the UI activity
                    mHandler.obtainMessage(MESSAGE_READ, bytes, -1, DadosBt).sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }
        }



        // Call this from the main activity to send data to the remote device
        public void enviar(String dadosEnviar) {
            byte[] msgBuffer = dadosEnviar.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException erro) {

            }
        }
    }

}
