package com.teste.eletricidade;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Main2Activity extends Activity {

    Button Simples, Bihorario, Trihorario, P1_15, P2_30, P3_45, P4_60, P5_75, P6_90, P10_35, P13_80, P17_25, P20_70, P27_60, P34_50, BtnOK;

    public String tarifa, MAC;
    public String potencia;
    boolean conexao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Simples = (Button) findViewById(R.id.Simples);  //Declara botoes
        Bihorario = (Button) findViewById(R.id.Bihorario);
        Trihorario = (Button) findViewById(R.id.Trihorario);
        P1_15 = (Button) findViewById(R.id.p1_15);
        P2_30 = (Button) findViewById(R.id.p2_3);
        P3_45 = (Button) findViewById(R.id.p3_45);
        P4_60 = (Button) findViewById(R.id.p4_6);
        P5_75 = (Button) findViewById(R.id.p5_75);
        P6_90 = (Button) findViewById(R.id.p6_9);
        P10_35 = (Button) findViewById(R.id.p10_35);
        P13_80 = (Button) findViewById(R.id.p13_8);
        P17_25 = (Button) findViewById(R.id.p17_25);
        P20_70 = (Button) findViewById(R.id.p20_7);
        P27_60 = (Button) findViewById(R.id.p27_6);
        P34_50 = (Button) findViewById(R.id.p34_5);
        BtnOK = (Button) findViewById(R.id.BtnOK);

        Intent intent = getIntent();
        MAC = intent.getStringExtra("MAC");
        conexao= intent.getBooleanExtra("conexao", false);


    Simples.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Simples", Toast.LENGTH_LONG).show();
        tarifa = "Simples";

        }
    });

    Bihorario.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Bihorario", Toast.LENGTH_LONG).show();
            tarifa = "Bihorario";

        }
    });

    Trihorario.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Trihorario", Toast.LENGTH_LONG).show();
            tarifa = "Trihorario";
        }
    });

    P1_15.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 1.15 kW", Toast.LENGTH_LONG).show();
            potencia = "1.15";
        }
    });

    P2_30.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 2.30 kW", Toast.LENGTH_LONG).show();
            potencia = "2.30";
        }
    });
                P3_45.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 3.45 kW", Toast.LENGTH_LONG).show();
            potencia = "3.45";
        }
    });

                P4_60.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 4.60 kW", Toast.LENGTH_LONG).show();
            potencia = "4.60";

        }
    });
                P5_75.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 5.75 kW", Toast.LENGTH_LONG).show();
            potencia = "5.75";
        }
    });
                P6_90.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 6.90 kW", Toast.LENGTH_LONG).show();
            potencia = "6.90";
        }
    });
                P10_35.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 10.35 kW", Toast.LENGTH_LONG).show();
            potencia = "10.35";
        }
    });
                P13_80.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 13.80 kW", Toast.LENGTH_LONG).show();
            potencia = "13.80";
        }
    });
                P17_25.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 17.25 kW", Toast.LENGTH_LONG).show();
            potencia = "17.25";
        }
    });
                P20_70.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 20.70 kW", Toast.LENGTH_LONG).show();
            potencia = "20.70";
        }
    });
                P27_60.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Potência = 27.60 kW", Toast.LENGTH_LONG).show();
                potencia = "27.60";
        }
    });
                P34_50.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Potência = 34.50 kW", Toast.LENGTH_LONG).show();
            potencia = "34.50";
        }
    });

                BtnOK.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent pagina3 = new Intent(Main2Activity.this, Main3Activity.class);
            pagina3.putExtra("tarifa", tarifa);
            pagina3.putExtra("potencia", potencia);
            pagina3.putExtra("MAC", MAC);
            pagina3.putExtra("conexao", conexao);

            startActivity(pagina3);

        };
    });

    }

}
